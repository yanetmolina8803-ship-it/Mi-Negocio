# Mi Negocio — Proyecto Android

Aplicación Android que funciona sin conexión y guarda los datos localmente en el dispositivo.

## Inversión principal
- Muestra un listado de los productos registrados en compras anteriores.
- Permite reutilizar nombres y cargar el último precio de venta de un producto.
- Permite añadir varios productos a una misma compra antes de guardarla.
- Cada producto mantiene cantidad, unidad, contenido, costo, precio de venta y ganancia real.
- Conserva historial de compras, edición y eliminación de registros.

## Construir la APK
El proyecto se puede compilar con Java 17 y Gradle 8.9 desde GitHub Actions. Al terminar correctamente, descarga el artefacto `Mi-Negocio-APK` desde la ejecución de Actions.

## Datos
Los registros se guardan localmente en el almacenamiento web de la aplicación. Usa la opción de exportar respaldo periódicamente; borrar los datos de la app o desinstalarla puede eliminar los registros locales.
