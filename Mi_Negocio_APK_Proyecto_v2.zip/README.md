# Mi Negocio — APK Android

Aplicación Android sin conexión para registrar inversión principal, inversión personal, deudas y reportes. Los registros se guardan localmente en el almacenamiento web de la aplicación (localStorage).

## Crear la APK desde GitHub en el navegador del teléfono

1. Sube el contenido de este ZIP al repositorio GitHub, no solamente el archivo ZIP.
2. Asegúrate de que la carpeta `.github/workflows` y el archivo `build-apk.yml` estén en el repositorio.
3. Abre la pestaña **Actions** del repositorio.
4. Entra en **Crear APK Mi Negocio** y pulsa **Run workflow** (si aparece). También se inicia automáticamente al subir los archivos a `main` o `master`.
5. Espera a que termine con una marca verde.
6. Abre la ejecución completada y busca **Artifacts** → **Mi-Negocio-APK**. Descarga el ZIP del artefacto y descomprímelo para encontrar `app-debug.apk`.
7. Abre el APK en Android y permite instalar aplicaciones desde esa fuente si el teléfono lo solicita.

## Cálculos

- Costo por unidad pequeña = costo total / total de unidades pequeñas.
- Precio objetivo para margen de 10% sobre la venta = costo / 0.90.
- Ganancia objetivo = (costo / 0.90) − costo.
- Ganancia estimada = venta estimada total − costo total.
- Ganancia real se introduce manualmente.
- Los pagos de deudas se acumulan; si superan la deuda, se muestra el excedente a favor del deudor.

## Importante

Esta es una primera versión funcional. No requiere conexión para usar los registros después de instalarse. Usa **Reportes → Exportar copia de seguridad** con regularidad; si borras los datos de la app o la desinstalas, los registros locales pueden perderse. La APK de depuración no está publicada en Google Play.
